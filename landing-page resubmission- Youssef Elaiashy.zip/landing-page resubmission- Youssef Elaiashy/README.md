** My Landing Page Project ** Student: Youssef El-Aiashy	

*Description:
 landing page with navigation bar in which navigation bar style and section style changes according to the scroll of user.

-I used the Project starter code as showed
-One page holds 4 sections, you can scroll between them and notice how the style of each section changes.
-Style changes when bith the top and bottom of the section are in the window view port.
-According to the active section the navigation bar shows which section is active too with some simple style changes.


*Edits in re-submission:

1/For the usability: i re-edited the condition in if statment to be usable with mobile phone. 
Changed the condition to only depend on the top of the section to solve this issue>
2/Made anctive section by default using JS and removed it from HTML, Section1 is active by default now.
***********************************************************************************************************************
 Hope u like it :)
